// VARIÁVEIS
let nome = "Daniel";
let sobrenome = "Pimentel";
let nome_completo = `${nome} ${sobrenome}`;
console.log(nome_completo);

let nascimento = 2006;
let ano = 2024;
let idade = ano - nascimento;

console.log("Você nasceu no ano de " + nascimento + " e estamos no ano de " + ano + ". Logo, você tem " + idade + "anos.");
console.log(`Você nasceu no ano de ${nascimento} e estamos no ano de ${ano}. Logo, você tem ${idade} anos.`);